from flask import Flask, request, render_template_string, url_for

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        name = request.form.get("name", "神秘人")
        animal = request.form.get("animal", "cat1")

        animal_images = {
            "cat1": url_for('static', filename='images/cat1.jpg'),
            "dog1": url_for('static', filename='images/dog1.jpg'),
            "rabbit1": url_for('static', filename='images/rabbit1.jpg')
        }

        animal_music = {
            "cat1": url_for('static', filename='music/bgm.mp3'),
            "dog1": url_for('static', filename='music/bark.mp3'),
            "rabbit1": url_for('static', filename='music/silence.mp3')
        }

        img_src = animal_images.get(animal, animal_images["cat1"])
        music_src = animal_music.get(animal, animal_music["cat1"])

        background_img = url_for('static', filename='images/zoo.jpg')

        return render_template_string("""
        <html>
        <head>
            <style>
                body {
                    background-image: url('{{ background_img }}');
                    background-size: cover;
                    background-position: center;
                    color: white;
                    font-family: Arial, sans-serif;
                    text-align: center;
                    margin-top: 50px;
                }
                canvas {
                    position: fixed;
                    top: 0;
                    left: 0;
                    pointer-events: none;
                    z-index: 999;
                }
                audio {
                    position: fixed;
                    bottom: 10px;
                    left: 10px;
                    z-index: 1000;
                }
            </style>
        </head>
        <body>
            <audio autoplay loop controls>
                <source src="{{ music_src }}" type="audio/mpeg">
                你嘅瀏覽器唔支援音樂播放 😢
            </audio>

            <canvas id="fireworks"></canvas>
            <h1>Hello，{{ name }}！👋</h1>
            <p>你揀咗嘅動物係：<strong>{{ animal }}</strong></p>
            <img src="{{ img_src }}" alt="我隻{{ animal }}" style="max-width:300px; height:auto;">
            <br><br>
            <a href="/" style="color: #00ffff;">返回</a><br><br>
            <a href="https://www.google.com" target="_blank" rel="noopener noreferrer" style="color: #00ff99;">去 Google 搵嘢</a>

            <script>
            const canvas = document.getElementById('fireworks');
            const ctx = canvas.getContext('2d');
            let w = canvas.width = window.innerWidth;
            let h = canvas.height = window.innerHeight;

            const fireworks = [];

            function random(min, max) {
                return Math.random() * (max - min) + min;
            }

            function Firework() {
                this.x = random(0, w);
                this.y = random(0, h / 2);
                this.r = random(2, 4);
                this.color = `hsl(${Math.floor(random(0, 360))}, 100%, 50%)`;
                this.alpha = 1;
                this.fade = random(0.01, 0.03);
            }

            Firework.prototype.update = function () {
                this.alpha -= this.fade;
            }

            Firework.prototype.draw = function () {
                ctx.globalAlpha = this.alpha;
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
                ctx.fillStyle = this.color;
                ctx.fill();
                ctx.globalAlpha = 1;
            }

            function animate() {
                ctx.clearRect(0, 0, w, h);
                if (Math.random() < 0.1) fireworks.push(new Firework());
                for (let i = fireworks.length - 1; i >= 0; i--) {
                    fireworks[i].update();
                    fireworks[i].draw();
                    if (fireworks[i].alpha <= 0) fireworks.splice(i, 1);
                }
                requestAnimationFrame(animate);
            }

            animate();
            </script>
        </body>
        </html>
        """, name=name, animal=animal, img_src=img_src, music_src=music_src, background_img=background_img)

    return render_template_string("""
    <h1>你好！請輸入你個名：😎</h1>
    <form method="post">
        <input type="text" name="name" placeholder="例如：駿" required>
        <br><br>
        <label for="animal">你最鍾意邊隻動物？</label>
        <select name="animal" id="animal">
            <option value="cat1">貓 🐱</option>
            <option value="dog1">狗 🐶</option>
            <option value="rabbit1">兔 🐰</option>
        </select>
        <br><br>
        <button type="submit">打招呼！</button>
    </form>
    """)

if __name__ == "__main__":
    app.run(debug=False)

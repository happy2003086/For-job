from flask import Flask, request, render_template_string

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        name = request.form.get("name", "神秘人")
        return render_template_string("""
            <h1>Hello，{{ name }}！👋</h1>
            <img src="/static/images/downloadcat.jpg" alt="我隻貓" style="max-width:300px; height:auto;">
            <br>
            <a href="/">返回</a><br><br>
            <a href="https://www.google.com" target="_blank" rel="noopener noreferrer">去 Google 搵嘢</a>
        """, name=name)

    return render_template_string("""
        <h1>你好！請輸入你個名：😎</h1>
        <form method="post">
            <input type="text" name="name" placeholder="例如：駿" required>
            <button type="submit">打招呼！</button>
        </form>
        <br>
        <img src="/static/images/downloadcat.jpg" alt="我隻貓" style="max-width:300px; height:auto;">
        <br>
        <a href="https://www.google.com" target="_blank" rel="noopener noreferrer">去 Google 搵嘢</a>
    """)

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")



